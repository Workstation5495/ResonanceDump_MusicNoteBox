$code = '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);'
$type = Add-Type -MemberDefinition $code -Name "Win32" -Namespace "Win32" -PassThru
[void]$type::ShowWindowAsync((Get-Process -Id $PID).MainWindowHandle, 0)

$target = $args[0]
if (-not $target -or -not (Test-Path $target)) { exit }

$notes = @{
    "C4"=261; "D4"=294; "E4"=330; "F4"=349; "G4"=392; "A4"=440; "B4"=494; "C5"=523
}
$currentDuration = 300

try {
    $lines = [System.IO.File]::ReadAllLines($target)
    foreach ($line in $lines) {
        $l = $line.Trim()
        if ($l.StartsWith("#") -or -not $l) { continue }

        if ($l -match 'soundbox\s*=\s*\[(\d+)\]') {
            $currentDuration = [int]$Matches[1]
            continue
        }

        $allMatches = [regex]::Matches($l, '\[([A-G][\d]?)\]')
        foreach ($m in $allMatches) {
            $n = $m.Groups[1].Value
            if ($notes.ContainsKey($n)) {
                $freq = $notes[$n]
                [console]::Beep($freq, $currentDuration)
            }
        }
    }
} catch { exit }