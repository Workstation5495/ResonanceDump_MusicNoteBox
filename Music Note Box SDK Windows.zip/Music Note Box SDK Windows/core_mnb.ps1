# --- Resonance Dump: MNB ENGINE ---
# Developed by Workstation5495

$file = $args[0]
if (-not $file) { exit }

$defaultDuration = 300
$notes = @{
    'C4'=261.63; 'C#4'=277.18; 'D4'=293.66; 'D#4'=311.13; 'E4'=329.63; 'F4'=349.23
    'F#4'=369.99; 'G4'=392.00; 'G#4'=415.30; 'A4'=440.00; 'A#4'=466.16; 'B4'=493.88
    'C5'=523.25; 'C#5'=554.37; 'D5'=587.33; 'D#5'=622.25; 'E5'=659.25; 'F5'=698.46
    'F#5'=739.99; 'G5'=783.99; 'G#5'=830.61; 'A5'=880.00; 'A#5'=932.33; 'B5'=987.77
}

Get-Content $file | ForEach-Object {
    $line = $_.Trim()
    
    if ($line.StartsWith("#") -or [string]::IsNullOrWhiteSpace($line)) { return }

    if ($line -match 'soundbox\s*=\s*\[(\d+)\]') {
        $defaultDuration = [int]$matches[1]
    }

    $tokens = [regex]::Matches($line, '\[(.*?)\]')
    foreach ($token in $tokens) {
        $val = $token.Groups[1].Value

        if ($val -eq "P") {
            Start-Sleep -Milliseconds $defaultDuration
        }
        elseif ($notes.ContainsKey($val)) {
            [console]::Beep($notes[$val], $defaultDuration)
        }
    }
}